Machine Mobile UI (v1.0)
October 10, 2016

Artist: EvilSystem (evilsystem.eu / evil-s.deviantart.com)
Contact: evilsystem@duloclan.com 

This is a mobile-friendly UI. 

The product features:

- PSD Files 
- Vector Design (Scalable)
- Sliced images (PNG, High Resolution) 
- 41 button icons 
- Fonts included 
- Custom scripts 
- Demo scenes 
- Prefabs 

The images are sliced from PSD files scaled up to 200%.

Contact me if you need any assistance or have a question. 
With best regards, Evil.